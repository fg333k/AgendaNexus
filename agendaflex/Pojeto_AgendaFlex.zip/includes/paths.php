<?

    $CAMINHO_TELA_LOGIN = "/agendaflex/login.php";
    $CAMINHO_TELA_DASHBOARD = "/agendaflex/dashboard.php";
    $CAMINHO_

?>